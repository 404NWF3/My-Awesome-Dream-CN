"""Browser authentication flow."""
